"use client"

import { useState, useCallback } from "react"
import { Navbar } from "@/components/navbar"
import { HeroSection } from "@/components/hero-section"
import { AddFoodSection } from "@/components/add-food-section"
import { ViewFoodSection } from "@/components/view-food-section"
import { FeaturesSection } from "@/components/features-section"
import { Footer } from "@/components/footer"
import { Toast } from "@/components/toast-notification"

export interface FoodItem {
  id: string
  name: string
  quantity: string
  location: string
  contact: string
  expiryTime: string
  category: "vegetables" | "fruits" | "cooked" | "bakery" | "dairy" | "other"
  preferredPickupPoint: "college-gate" | "canteen" | "hostel-entrance" | "public-spot"
  status: "available" | "scheduled" | "completed"
  scheduledPickupLocation?: string
  createdAt: Date
}

const INITIAL_FOOD_ITEMS: FoodItem[] = [
  {
    id: "1",
    name: "Fresh Vegetables",
    quantity: "5 kg",
    location: "Downtown Area",
    contact: "+1 234 567 8900",
    expiryTime: "2 hours",
    category: "vegetables",
    preferredPickupPoint: "college-gate",
    status: "available",
    createdAt: new Date(),
  },
  {
    id: "2",
    name: "Homemade Bread",
    quantity: "3 loaves",
    location: "Midtown Area",
    contact: "+1 234 567 8901",
    expiryTime: "4 hours",
    category: "bakery",
    preferredPickupPoint: "canteen",
    status: "available",
    createdAt: new Date(),
  },
  {
    id: "3",
    name: "Cooked Rice",
    quantity: "2 kg",
    location: "Uptown Area",
    contact: "+1 234 567 8902",
    expiryTime: "1 hour",
    category: "cooked",
    preferredPickupPoint: "hostel-entrance",
    status: "scheduled",
    scheduledPickupLocation: "Hostel Entrance",
    createdAt: new Date(),
  },
  {
    id: "4",
    name: "Fresh Apples",
    quantity: "10 pieces",
    location: "Westside Area",
    contact: "+1 234 567 8903",
    expiryTime: "6 hours",
    category: "fruits",
    preferredPickupPoint: "public-spot",
    status: "available",
    createdAt: new Date(),
  },
]

export default function Home() {
  const [foodItems, setFoodItems] = useState<FoodItem[]>(INITIAL_FOOD_ITEMS)
  const [activeSection, setActiveSection] = useState<"home" | "add" | "view">("home")
  const [toast, setToast] = useState({ isVisible: false, message: "", type: "success" as const })

  const showToast = useCallback((message: string, type: "success" | "error" = "success") => {
    setToast({ isVisible: true, message, type })
  }, [])

  const hideToast = useCallback(() => {
    setToast((prev) => ({ ...prev, isVisible: false }))
  }, [])

  const handleAddFood = useCallback((newFood: Omit<FoodItem, "id" | "createdAt">) => {
    const food: FoodItem = {
      ...newFood,
      id: Date.now().toString(),
      createdAt: new Date(),
    }
    setFoodItems((prev) => [food, ...prev])
    setActiveSection("view")
    showToast("Food shared successfully! Thank you for contributing.")
  }, [showToast])

  const handleSchedulePickup = useCallback((id: string, pickupLocation: string) => {
    setFoodItems((prev) =>
      prev.map((item) =>
        item.id === id
          ? { ...item, status: "scheduled" as const, scheduledPickupLocation: pickupLocation }
          : item
      )
    )
    showToast(`Pickup scheduled at ${pickupLocation}!`)
  }, [showToast])

  const handleMarkAsCompleted = useCallback((id: string) => {
    setFoodItems((prev) =>
      prev.map((item) =>
        item.id === id ? { ...item, status: "completed" as const } : item
      )
    )
    showToast("Pickup completed! Thank you for reducing food waste.")
  }, [showToast])

  const handleRemoveItem = useCallback((id: string) => {
    setFoodItems((prev) => prev.filter((item) => item.id !== id))
    showToast("Food item removed from the list.")
  }, [showToast])

  return (
    <main className="min-h-screen bg-background">
      <Navbar activeSection={activeSection} setActiveSection={setActiveSection} />
      
      <div className="transition-all duration-300">
        {activeSection === "home" && (
          <div className="animate-in fade-in duration-300">
            <HeroSection setActiveSection={setActiveSection} />
            <FeaturesSection />
          </div>
        )}
        
        {activeSection === "add" && (
          <div className="animate-in fade-in slide-in-from-right-4 duration-300">
            <AddFoodSection onAddFood={handleAddFood} />
          </div>
        )}
        
        {activeSection === "view" && (
          <div className="animate-in fade-in slide-in-from-left-4 duration-300">
            <ViewFoodSection 
              foodItems={foodItems} 
              onSchedulePickup={handleSchedulePickup}
              onMarkAsCompleted={handleMarkAsCompleted}
              onRemoveItem={handleRemoveItem}
            />
          </div>
        )}
      </div>
      
      <Footer />
      
      <Toast
        message={toast.message}
        type={toast.type}
        isVisible={toast.isVisible}
        onClose={hideToast}
      />
    </main>
  )
}
