"use client"

import { Button } from "@/components/ui/button"
import { ArrowRight, Heart, Utensils } from "lucide-react"

interface HeroSectionProps {
  setActiveSection: (section: "home" | "add" | "view") => void
}

export function HeroSection({ setActiveSection }: HeroSectionProps) {
  return (
    <section className="relative overflow-hidden px-4 py-20 sm:px-6 lg:px-8 lg:py-32">
      {/* Background decoration */}
      <div className="absolute inset-0 -z-10">
        <div className="absolute left-1/4 top-1/4 h-96 w-96 rounded-full bg-primary/10 blur-3xl" />
        <div className="absolute bottom-1/4 right-1/4 h-96 w-96 rounded-full bg-accent/10 blur-3xl" />
      </div>

      <div className="mx-auto max-w-7xl">
        <div className="grid items-center gap-12 lg:grid-cols-2 lg:gap-16">
          {/* Content */}
          <div className="text-center lg:text-left">
            <div className="mb-6 inline-flex items-center gap-2 rounded-full bg-primary/10 px-4 py-2 text-sm font-medium text-primary">
              <Heart className="h-4 w-4" />
              Join the movement against food waste
            </div>
            
            <h1 className="mb-6 text-balance text-4xl font-bold tracking-tight text-foreground sm:text-5xl lg:text-6xl">
              {"Don't Waste Food"} — <span className="text-primary">Share It</span>
            </h1>
            
            <p className="mb-8 max-w-xl text-pretty text-lg leading-relaxed text-muted-foreground lg:text-xl">
              ShareBite connects people with extra food to those who need it. Together, we can reduce waste, 
              fight hunger, and build a more sustainable community.
            </p>

            <div className="flex flex-col gap-4 sm:flex-row sm:justify-center lg:justify-start">
              <Button
                size="lg"
                onClick={() => setActiveSection("add")}
                className="group gap-2 rounded-full px-8 shadow-lg shadow-primary/25 transition-all duration-300 hover:shadow-xl hover:shadow-primary/30"
              >
                Add Food
                <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
              </Button>
              <Button
                size="lg"
                variant="outline"
                onClick={() => setActiveSection("view")}
                className="rounded-full px-8 transition-all duration-300 hover:bg-secondary"
              >
                View Available Food
              </Button>
            </div>

            {/* Stats */}
            <div className="mt-12 grid grid-cols-3 gap-6">
              {[
                { value: "500+", label: "Meals Shared" },
                { value: "200+", label: "Active Users" },
                { value: "50kg", label: "Food Saved" },
              ].map((stat) => (
                <div key={stat.label} className="text-center lg:text-left">
                  <div className="text-2xl font-bold text-primary sm:text-3xl">{stat.value}</div>
                  <div className="text-sm text-muted-foreground">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Illustration */}
          <div className="relative flex items-center justify-center lg:justify-end">
            <div className="relative">
              {/* Main circle */}
              <div className="flex h-72 w-72 items-center justify-center rounded-full bg-gradient-to-br from-primary/20 to-accent/20 sm:h-96 sm:w-96">
                <div className="flex h-56 w-56 items-center justify-center rounded-full bg-gradient-to-br from-primary/30 to-accent/30 sm:h-72 sm:w-72">
                  <div className="flex h-40 w-40 items-center justify-center rounded-full bg-primary shadow-2xl shadow-primary/40 sm:h-48 sm:w-48">
                    <Utensils className="h-16 w-16 text-primary-foreground sm:h-20 sm:w-20" />
                  </div>
                </div>
              </div>

              {/* Floating elements */}
              <div className="absolute -right-4 top-8 animate-bounce rounded-2xl bg-card p-4 shadow-xl">
                <div className="flex items-center gap-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10">
                    <Heart className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <div className="text-sm font-semibold text-foreground">New Share!</div>
                    <div className="text-xs text-muted-foreground">Fresh vegetables</div>
                  </div>
                </div>
              </div>

              <div className="absolute -left-4 bottom-8 animate-bounce rounded-2xl bg-card p-4 shadow-xl" style={{ animationDelay: "0.5s" }}>
                <div className="flex items-center gap-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-accent/20">
                    <Utensils className="h-5 w-5 text-accent" />
                  </div>
                  <div>
                    <div className="text-sm font-semibold text-foreground">Food Saved</div>
                    <div className="text-xs text-muted-foreground">2kg this week</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
