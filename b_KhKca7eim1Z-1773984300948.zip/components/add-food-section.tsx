"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Clock, MapPin, Phone, Package, Utensils, Sparkles, Apple, Croissant, Milk, Salad, Navigation, ShieldCheck, AlertTriangle } from "lucide-react"
import type { FoodItem } from "@/app/page"

interface AddFoodSectionProps {
  onAddFood: (food: Omit<FoodItem, "id" | "createdAt">) => void
}

const CATEGORIES = [
  { value: "vegetables", label: "Vegetables", icon: Salad },
  { value: "fruits", label: "Fruits", icon: Apple },
  { value: "cooked", label: "Cooked Food", icon: Utensils },
  { value: "bakery", label: "Bakery", icon: Croissant },
  { value: "dairy", label: "Dairy", icon: Milk },
  { value: "other", label: "Other", icon: Package },
] as const

const PICKUP_POINTS = [
  { value: "college-gate", label: "College Gate" },
  { value: "canteen", label: "Canteen" },
  { value: "hostel-entrance", label: "Hostel Entrance" },
  { value: "public-spot", label: "Public Spot" },
] as const

export function AddFoodSection({ onAddFood }: AddFoodSectionProps) {
  const [formData, setFormData] = useState({
    name: "",
    quantity: "",
    location: "",
    contact: "",
    expiryTime: "",
    category: "" as FoodItem["category"] | "",
    preferredPickupPoint: "" as FoodItem["preferredPickupPoint"] | "",
    customPickupPoint: "",
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [errors, setErrors] = useState<Record<string, string>>({})

  const validateForm = () => {
    const newErrors: Record<string, string> = {}
    
    if (!formData.name.trim()) newErrors.name = "Food name is required"
    if (!formData.quantity.trim()) newErrors.quantity = "Quantity is required"
    if (!formData.location.trim()) newErrors.location = "Location is required"
    if (!formData.contact.trim()) newErrors.contact = "Contact is required"
    if (!formData.expiryTime.trim()) newErrors.expiryTime = "Availability time is required"
    if (!formData.category) newErrors.category = "Category is required"
    if (!formData.preferredPickupPoint) newErrors.preferredPickupPoint = "Preferred pickup point is required"
    
    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!validateForm()) return
    
    setIsSubmitting(true)
    
    await new Promise((resolve) => setTimeout(resolve, 500))
    
    onAddFood({
      name: formData.name,
      quantity: formData.quantity,
      location: formData.location,
      contact: formData.contact,
      expiryTime: formData.expiryTime,
      category: formData.category as FoodItem["category"],
      preferredPickupPoint: formData.preferredPickupPoint as FoodItem["preferredPickupPoint"],
      customPickupPoint: formData.customPickupPoint || undefined,
      status: "available",
    })
    
    setFormData({
      name: "",
      quantity: "",
      location: "",
      contact: "",
      expiryTime: "",
      category: "",
      preferredPickupPoint: "",
      customPickupPoint: "",
    })
    setErrors({})
    setIsSubmitting(false)
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData({ ...formData, [name]: value })
    if (errors[name]) {
      setErrors({ ...errors, [name]: "" })
    }
  }

  const inputFields = [
    {
      id: "name",
      label: "Food Name",
      placeholder: "e.g., Fresh Vegetables, Cooked Rice",
      icon: Utensils,
      type: "text",
    },
    {
      id: "quantity",
      label: "Quantity",
      placeholder: "e.g., 2 kg, 5 portions",
      icon: Package,
      type: "text",
    },
    {
      id: "location",
      label: "Area Name",
      placeholder: "e.g., Downtown, Midtown, Westside",
      icon: MapPin,
      type: "text",
    },
    {
      id: "contact",
      label: "Contact Number",
      placeholder: "e.g., +1 234 567 8900",
      icon: Phone,
      type: "tel",
    },
    {
      id: "expiryTime",
      label: "Available Until",
      placeholder: "e.g., 2 hours, Today 6 PM",
      icon: Clock,
      type: "text",
    },
  ]

  return (
    <section className="px-4 py-16 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-2xl">
        <div className="mb-10 text-center">
          <div className="mb-4 inline-flex items-center gap-2 rounded-full bg-primary/10 px-4 py-2 text-sm font-medium text-primary">
            <Sparkles className="h-4 w-4" />
            Share your extra food
          </div>
          <h2 className="mb-4 text-balance text-3xl font-bold text-foreground sm:text-4xl">
            Add Food to Share
          </h2>
          <p className="text-pretty text-muted-foreground">
            Fill in the details below to share your extra food with those who need it
          </p>
        </div>

        <Card className="border-border/50 bg-card/80 shadow-xl shadow-primary/5 backdrop-blur-sm">
          <CardHeader className="text-center">
            <CardTitle className="flex items-center justify-center gap-2 text-xl">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10">
                <Utensils className="h-5 w-5 text-primary" />
              </div>
              Food Details
            </CardTitle>
            <CardDescription>
              Provide accurate information to help others find your shared food
            </CardDescription>
            <div className="mt-4 flex items-center justify-center gap-2 rounded-full bg-green-500/10 px-4 py-2 text-sm font-medium text-green-600">
              <ShieldCheck className="h-4 w-4" />
              Safe & Verified Sharing
            </div>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              {inputFields.map((field) => (
                <div key={field.id} className="space-y-2">
                  <Label htmlFor={field.id} className="text-sm font-medium text-foreground">
                    {field.label}
                  </Label>
                  <div className="relative">
                    <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-4">
                      <field.icon className="h-5 w-5 text-muted-foreground" />
                    </div>
                    <Input
                      id={field.id}
                      name={field.id}
                      type={field.type}
                      placeholder={field.placeholder}
                      value={formData[field.id as keyof typeof formData]}
                      onChange={handleChange}
                      aria-describedby={errors[field.id] ? `${field.id}-error` : undefined}
                      aria-invalid={!!errors[field.id]}
                      className={`h-12 rounded-xl border-border/50 bg-background pl-12 transition-all duration-200 focus:border-primary focus:ring-2 focus:ring-primary/20 ${
                        errors[field.id] ? "border-destructive focus:border-destructive focus:ring-destructive/20" : ""
                      }`}
                    />
                  </div>
                  {errors[field.id] && (
                    <p id={`${field.id}-error`} className="text-sm text-destructive">
                      {errors[field.id]}
                    </p>
                  )}
                </div>
              ))}

              {/* Category Select */}
              <div className="space-y-2">
                <Label htmlFor="category" className="text-sm font-medium text-foreground">
                  Food Category
                </Label>
                <Select
                  value={formData.category}
                  onValueChange={(value) => {
                    setFormData({ ...formData, category: value as FoodItem["category"] })
                    if (errors.category) {
                      setErrors({ ...errors, category: "" })
                    }
                  }}
                >
                  <SelectTrigger
                    id="category"
                    aria-describedby={errors.category ? "category-error" : undefined}
                    aria-invalid={!!errors.category}
                    className={`h-12 rounded-xl border-border/50 bg-background transition-all duration-200 focus:border-primary focus:ring-2 focus:ring-primary/20 ${
                      errors.category ? "border-destructive focus:border-destructive focus:ring-destructive/20" : ""
                    }`}
                  >
                    <SelectValue placeholder="Select a category" />
                  </SelectTrigger>
                  <SelectContent>
                    {CATEGORIES.map((category) => (
                      <SelectItem key={category.value} value={category.value}>
                        <span className="flex items-center gap-2">
                          <category.icon className="h-4 w-4" />
                          {category.label}
                        </span>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {errors.category && (
                  <p id="category-error" className="text-sm text-destructive">
                    {errors.category}
                  </p>
                )}
              </div>

              {/* Preferred Pickup Point Select */}
              <div className="space-y-2">
                <Label htmlFor="preferredPickupPoint" className="text-sm font-medium text-foreground">
                  Preferred Pickup Location
                </Label>
                <div className="relative">
                  <div className="pointer-events-none absolute inset-y-0 left-0 z-10 flex items-center pl-4">
                    <Navigation className="h-5 w-5 text-muted-foreground" />
                  </div>
                  <Select
                    value={formData.preferredPickupPoint}
                    onValueChange={(value) => {
                      setFormData({ 
                        ...formData, 
                        preferredPickupPoint: value as FoodItem["preferredPickupPoint"],
                        customPickupPoint: value !== "custom" ? "" : formData.customPickupPoint
                      })
                      if (errors.preferredPickupPoint) {
                        setErrors({ ...errors, preferredPickupPoint: "" })
                      }
                    }}
                  >
                    <SelectTrigger
                      id="preferredPickupPoint"
                      aria-describedby={errors.preferredPickupPoint ? "preferredPickupPoint-error" : undefined}
                      aria-invalid={!!errors.preferredPickupPoint}
                      className={`h-12 rounded-xl border-border/50 bg-background pl-12 transition-all duration-200 focus:border-primary focus:ring-2 focus:ring-primary/20 ${
                        errors.preferredPickupPoint ? "border-destructive focus:border-destructive focus:ring-destructive/20" : ""
                      }`}
                    >
                      <SelectValue placeholder="Select a pickup point" />
                    </SelectTrigger>
                    <SelectContent>
                      {PICKUP_POINTS.map((point) => (
                        <SelectItem key={point.value} value={point.value}>
                          {point.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                {errors.preferredPickupPoint && (
                  <p id="preferredPickupPoint-error" className="text-sm text-destructive">
                    {errors.preferredPickupPoint}
                  </p>
                )}
              </div>

              {/* Safety Warning */}
              <div className="flex items-start gap-3 rounded-xl bg-amber-500/10 border border-amber-500/20 p-4">
                <AlertTriangle className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
                <p className="text-sm text-amber-700">
                  For safety, do not share your exact home address. Always meet at a public pickup point.
                </p>
              </div>

              <Button
                type="submit"
                disabled={isSubmitting}
                className="group h-12 w-full rounded-xl text-base font-semibold shadow-lg shadow-primary/25 transition-all duration-300 hover:shadow-xl hover:shadow-primary/30"
              >
                {isSubmitting ? (
                  <span className="flex items-center gap-2">
                    <svg className="h-5 w-5 animate-spin" viewBox="0 0 24 24" aria-hidden="true">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                    </svg>
                    Sharing...
                  </span>
                ) : (
                  <span className="flex items-center gap-2">
                    Share Food
                    <Sparkles className="h-4 w-4 transition-transform group-hover:rotate-12" aria-hidden="true" />
                  </span>
                )}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </section>
  )
}
