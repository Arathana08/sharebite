"use client"

import { Recycle, Heart, Zap, Globe } from "lucide-react"

const features = [
  {
    icon: Recycle,
    title: "Reduce Food Waste",
    description: "Help prevent perfectly good food from ending up in landfills. Every share makes a difference.",
  },
  {
    icon: Heart,
    title: "Help People in Need",
    description: "Connect your surplus food with community members who could use a helping hand.",
  },
  {
    icon: Zap,
    title: "Easy to Use",
    description: "Simple interface to share or find food in seconds. No complicated processes, just share and help.",
  },
  {
    icon: Globe,
    title: "Sustainable Impact",
    description: "Join a growing community committed to building a more sustainable and caring world.",
  },
]

export function FeaturesSection() {
  return (
    <section className="border-t border-border/40 bg-muted/30 px-4 py-20 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-7xl">
        <div className="mb-16 text-center">
          <h2 className="mb-4 text-balance text-3xl font-bold text-foreground sm:text-4xl">
            Why Choose ShareBite?
          </h2>
          <p className="mx-auto max-w-2xl text-pretty text-lg text-muted-foreground">
            Our platform makes it easy to share food and make a positive impact on your community and the environment
          </p>
        </div>

        <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
          {features.map((feature, index) => (
            <div
              key={feature.title}
              className="group relative rounded-2xl border border-border/50 bg-card p-6 shadow-lg shadow-primary/5 transition-all duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-primary/10"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-xl bg-primary/10 transition-colors group-hover:bg-primary/20">
                <feature.icon className="h-7 w-7 text-primary" />
              </div>
              <h3 className="mb-2 text-lg font-semibold text-foreground">{feature.title}</h3>
              <p className="text-sm leading-relaxed text-muted-foreground">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
