"use client"

import { useEffect, useState } from "react"
import { CheckCircle2, X } from "lucide-react"
import { cn } from "@/lib/utils"

interface ToastProps {
  message: string
  type?: "success" | "error"
  isVisible: boolean
  onClose: () => void
}

export function Toast({ message, type = "success", isVisible, onClose }: ToastProps) {
  useEffect(() => {
    if (isVisible) {
      const timer = setTimeout(() => {
        onClose()
      }, 3000)
      return () => clearTimeout(timer)
    }
  }, [isVisible, onClose])

  if (!isVisible) return null

  return (
    <div
      className={cn(
        "fixed bottom-6 right-6 z-50 flex items-center gap-3 rounded-xl px-4 py-3 shadow-lg transition-all duration-300",
        type === "success" ? "bg-primary text-primary-foreground" : "bg-destructive text-destructive-foreground",
        isVisible ? "translate-y-0 opacity-100" : "translate-y-4 opacity-0"
      )}
      role="alert"
      aria-live="polite"
    >
      <CheckCircle2 className="h-5 w-5" />
      <span className="font-medium">{message}</span>
      <button
        onClick={onClose}
        className="ml-2 rounded-full p-1 transition-colors hover:bg-primary-foreground/20"
        aria-label="Dismiss notification"
      >
        <X className="h-4 w-4" />
      </button>
    </div>
  )
}
