"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { Clock, MapPin, Phone, CheckCircle2, Package, Search, Apple, Croissant, Milk, Salad, Utensils, X, Navigation, Calendar, Trash2, ShieldCheck } from "lucide-react"
import type { FoodItem } from "@/app/page"

interface ViewFoodSectionProps {
  foodItems: FoodItem[]
  onSchedulePickup: (id: string, pickupLocation: string) => void
  onMarkAsCompleted: (id: string) => void
  onRemoveItem: (id: string) => void
}

const CATEGORY_CONFIG = {
  vegetables: { label: "Vegetables", icon: Salad, color: "bg-green-500/10 text-green-600" },
  fruits: { label: "Fruits", icon: Apple, color: "bg-orange-500/10 text-orange-600" },
  cooked: { label: "Cooked", icon: Utensils, color: "bg-red-500/10 text-red-600" },
  bakery: { label: "Bakery", icon: Croissant, color: "bg-amber-500/10 text-amber-600" },
  dairy: { label: "Dairy", icon: Milk, color: "bg-blue-500/10 text-blue-600" },
  other: { label: "Other", icon: Package, color: "bg-gray-500/10 text-gray-600" },
}

const PICKUP_LOCATIONS = [
  { value: "college-gate", label: "College Gate" },
  { value: "canteen", label: "Canteen" },
  { value: "hostel-entrance", label: "Hostel Entrance" },
  { value: "public-spot", label: "Public Spot" },
]

const STATUS_CONFIG = {
  available: { label: "Available", color: "bg-green-500/10 text-green-600 border-green-500/20" },
  scheduled: { label: "Scheduled", color: "bg-yellow-500/10 text-yellow-600 border-yellow-500/20" },
  completed: { label: "Completed", color: "bg-gray-500/10 text-gray-500 border-gray-500/20" },
}

const ALL_CATEGORIES = ["all", "vegetables", "fruits", "cooked", "bakery", "dairy", "other"] as const
const ALL_STATUSES = ["all", "available", "scheduled", "completed"] as const

function getPickupPointLabel(item: FoodItem): string {
  const point = PICKUP_LOCATIONS.find(p => p.value === item.preferredPickupPoint)
  return point?.label || item.preferredPickupPoint
}

export function ViewFoodSection({ foodItems, onSchedulePickup, onMarkAsCompleted, onRemoveItem }: ViewFoodSectionProps) {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedCategory, setSelectedCategory] = useState<typeof ALL_CATEGORIES[number]>("all")
  const [selectedStatus, setSelectedStatus] = useState<typeof ALL_STATUSES[number]>("all")
  const [pickupModalItem, setPickupModalItem] = useState<FoodItem | null>(null)
  const [selectedPickupLocation, setSelectedPickupLocation] = useState<string>("")
  const [customLocation, setCustomLocation] = useState("")
  const [itemToComplete, setItemToComplete] = useState<string | null>(null)
  const [itemToRemove, setItemToRemove] = useState<string | null>(null)

  const filteredItems = foodItems.filter((item) => {
    const matchesSearch = item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.location.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesCategory = selectedCategory === "all" || item.category === selectedCategory
    const matchesStatus = selectedStatus === "all" || item.status === selectedStatus
    return matchesSearch && matchesCategory && matchesStatus
  })

  const handleOpenPickupModal = (item: FoodItem) => {
    setPickupModalItem(item)
    // Pre-select the donor's preferred pickup location
    setSelectedPickupLocation(item.preferredPickupPoint)
  }

  const handleConfirmPickup = () => {
    if (pickupModalItem && selectedPickupLocation) {
      const location = PICKUP_LOCATIONS.find(p => p.value === selectedPickupLocation)?.label || selectedPickupLocation
      onSchedulePickup(pickupModalItem.id, location)
      setPickupModalItem(null)
      setSelectedPickupLocation("")
    }
  }

  const handleConfirmComplete = () => {
    if (itemToComplete) {
      onMarkAsCompleted(itemToComplete)
      setItemToComplete(null)
    }
  }

  const handleConfirmRemove = () => {
    if (itemToRemove) {
      onRemoveItem(itemToRemove)
      setItemToRemove(null)
    }
  }

  const isPickupValid = !!selectedPickupLocation

  return (
    <section className="px-4 py-16 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-7xl">
        <div className="mb-12 text-center">
          <div className="mb-4 inline-flex items-center gap-2 rounded-full bg-primary/10 px-4 py-2 text-sm font-medium text-primary">
            <Package className="h-4 w-4" />
            Available now
          </div>
          <h2 className="mb-4 text-balance text-3xl font-bold text-foreground sm:text-4xl">
            Available Food Near You
          </h2>
          <p className="text-pretty text-muted-foreground">
            Browse available food items and help reduce waste in your community
          </p>
          <div className="mt-4 inline-flex items-center gap-2 rounded-full bg-green-500/10 px-4 py-2 text-sm font-medium text-green-600">
            <ShieldCheck className="h-4 w-4" />
            Safe & Verified Sharing
          </div>
        </div>

        {/* Search and Filter */}
        <div className="mb-8 space-y-4">
          <div className="relative mx-auto max-w-md">
            <Search className="absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search by food name or location..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="h-12 rounded-full border-border/50 bg-card pl-12 pr-4 shadow-sm transition-all focus:border-primary focus:ring-2 focus:ring-primary/20"
              aria-label="Search food items"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery("")}
                className="absolute right-4 top-1/2 -translate-y-1/2 rounded-full p-1 text-muted-foreground hover:bg-muted hover:text-foreground"
                aria-label="Clear search"
              >
                <X className="h-4 w-4" />
              </button>
            )}
          </div>

          {/* Category Filter */}
          <div className="flex flex-wrap items-center justify-center gap-2">
            {ALL_CATEGORIES.map((category) => {
              const isActive = selectedCategory === category
              return (
                <button
                  key={category}
                  onClick={() => setSelectedCategory(category)}
                  className={`rounded-full px-4 py-2 text-sm font-medium transition-all ${
                    isActive
                      ? "bg-primary text-primary-foreground shadow-lg shadow-primary/25"
                      : "bg-card text-muted-foreground hover:bg-secondary hover:text-foreground"
                  }`}
                  aria-pressed={isActive}
                >
                  {category === "all" ? "All" : CATEGORY_CONFIG[category].label}
                </button>
              )
            })}
          </div>

          {/* Status Filter */}
          <div className="flex flex-wrap items-center justify-center gap-2">
            {ALL_STATUSES.map((status) => {
              const isActive = selectedStatus === status
              return (
                <button
                  key={status}
                  onClick={() => setSelectedStatus(status)}
                  className={`rounded-full px-3 py-1.5 text-xs font-medium transition-all border ${
                    isActive
                      ? status === "all" 
                        ? "bg-primary text-primary-foreground border-primary"
                        : `${STATUS_CONFIG[status].color}`
                      : "bg-card text-muted-foreground border-border/50 hover:bg-secondary hover:text-foreground"
                  }`}
                  aria-pressed={isActive}
                >
                  {status === "all" ? "All Status" : STATUS_CONFIG[status].label}
                </button>
              )
            })}
          </div>
        </div>

        {filteredItems.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20">
            <div className="mb-4 flex h-20 w-20 items-center justify-center rounded-full bg-muted">
              <Package className="h-10 w-10 text-muted-foreground" />
            </div>
            <h3 className="mb-2 text-xl font-semibold text-foreground">
              {foodItems.length === 0 ? "No food available" : "No matching items"}
            </h3>
            <p className="text-center text-muted-foreground">
              {foodItems.length === 0
                ? "Be the first to share food with your community!"
                : "Try adjusting your search or filter criteria"}
            </p>
          </div>
        ) : (
          <>
            <p className="mb-6 text-center text-sm text-muted-foreground">
              Showing {filteredItems.length} {filteredItems.length === 1 ? "item" : "items"}
            </p>
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {filteredItems.map((item) => {
                const categoryConfig = CATEGORY_CONFIG[item.category]
                const CategoryIcon = categoryConfig.icon
                const statusConfig = STATUS_CONFIG[item.status]

                return (
                  <Card
                    key={item.id}
                    className={`group border-border/50 bg-card/80 shadow-lg shadow-primary/5 backdrop-blur-sm transition-all duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-primary/10 ${
                      item.status === "completed" ? "opacity-60" : ""
                    }`}
                  >
                    <CardHeader className="pb-3">
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10 transition-colors group-hover:bg-primary/20">
                          <CategoryIcon className="h-6 w-6 text-primary" />
                        </div>
                        <div className="flex flex-col items-end gap-1">
                          <Badge className={`${categoryConfig.color} border-0`}>
                            {categoryConfig.label}
                          </Badge>
                          <Badge className={`${statusConfig.color} border text-xs`}>
                            {statusConfig.label}
                          </Badge>
                        </div>
                      </div>
                      <h3 className="mt-3 text-xl font-semibold text-foreground">{item.name}</h3>
                      <p className="text-sm text-muted-foreground">Quantity: {item.quantity}</p>
                    </CardHeader>
                    
                    <CardContent className="space-y-3">
                      <div className="flex items-center gap-3 text-sm">
                        <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-secondary">
                          <MapPin className="h-4 w-4 text-muted-foreground" aria-hidden="true" />
                        </div>
                        <span className="text-muted-foreground">{item.location}</span>
                      </div>
                      
                      <div className="flex items-center gap-3 text-sm">
                        <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-secondary">
                          <Phone className="h-4 w-4 text-muted-foreground" aria-hidden="true" />
                        </div>
                        <span className="text-muted-foreground">{item.contact}</span>
                      </div>
                      
                      <div className="flex items-center gap-3 text-sm">
                        <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-secondary">
                          <Clock className="h-4 w-4 text-muted-foreground" aria-hidden="true" />
                        </div>
                        <span className="text-muted-foreground">Available for {item.expiryTime}</span>
                      </div>

                      {/* Pickup Point */}
                      <div className="flex items-center gap-3 text-sm">
                        <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10">
                          <Navigation className="h-4 w-4 text-primary" aria-hidden="true" />
                        </div>
                        <span className="font-medium text-primary">
                          Pickup: {getPickupPointLabel(item)}
                        </span>
                      </div>

                      {/* Scheduled Pickup Info */}
                      {item.status === "scheduled" && item.scheduledPickupLocation && (
                        <div className="mt-2 rounded-lg bg-yellow-500/10 p-3 border border-yellow-500/20">
                          <div className="flex items-center gap-2 text-sm font-medium text-yellow-600">
                            <Calendar className="h-4 w-4" />
                            Pickup Scheduled at: {item.scheduledPickupLocation}
                          </div>
                        </div>
                      )}

                      {/* Completed Info */}
                      {item.status === "completed" && (
                        <div className="mt-2 rounded-lg bg-gray-500/10 p-3 border border-gray-500/20">
                          <div className="flex items-center gap-2 text-sm font-medium text-gray-500">
                            <CheckCircle2 className="h-4 w-4" />
                            Pickup Completed
                          </div>
                        </div>
                      )}
                    </CardContent>

                    <CardFooter className="pt-3 flex flex-col gap-2">
                      {item.status === "available" && (
                        <Button
                          onClick={() => handleOpenPickupModal(item)}
                          className="group/btn w-full gap-2 rounded-xl shadow-lg shadow-primary/20 transition-all duration-300 hover:shadow-xl hover:shadow-primary/30"
                        >
                          <Navigation className="h-4 w-4 transition-transform group-hover/btn:scale-110" aria-hidden="true" />
                          Request Pickup
                        </Button>
                      )}
                      
                      {item.status === "scheduled" && (
                        <Button
                          onClick={() => setItemToComplete(item.id)}
                          variant="outline"
                          className="group/btn w-full gap-2 rounded-xl border-green-500/30 text-green-600 hover:bg-green-500/10 hover:text-green-700"
                        >
                          <CheckCircle2 className="h-4 w-4 transition-transform group-hover/btn:scale-110" aria-hidden="true" />
                          Mark as Completed
                        </Button>
                      )}

                      {item.status === "completed" && (
                        <Button
                          onClick={() => setItemToRemove(item.id)}
                          variant="outline"
                          className="group/btn w-full gap-2 rounded-xl border-destructive/30 text-destructive hover:bg-destructive/10"
                        >
                          <Trash2 className="h-4 w-4 transition-transform group-hover/btn:scale-110" aria-hidden="true" />
                          Remove from List
                        </Button>
                      )}
                    </CardFooter>
                  </Card>
                )
              })}
            </div>
          </>
        )}
      </div>

      {/* Pickup Modal */}
      <Dialog open={!!pickupModalItem} onOpenChange={() => setPickupModalItem(null)}>
        <DialogContent className="rounded-2xl sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Navigation className="h-5 w-5 text-primary" />
              Schedule Pickup
            </DialogTitle>
            <DialogDescription>
              The donor has set their preferred pickup location below. You can use it or suggest an alternative.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            {/* Donor's Preferred Location Highlight */}
            {pickupModalItem && (
              <div className="rounded-xl bg-primary/5 border border-primary/20 p-4">
                <p className="text-xs font-medium text-primary mb-2">Donor&apos;s Preferred Location</p>
                <div className="flex items-center gap-2">
                  <Navigation className="h-5 w-5 text-primary" />
                  <span className="font-semibold text-foreground">{getPickupPointLabel(pickupModalItem)}</span>
                </div>
              </div>
            )}
            
            <Label className="text-sm font-medium">Choose Pickup Location</Label>
            <div className="grid gap-2">
              {PICKUP_LOCATIONS.map((location) => (
                <button
                  key={location.value}
                  onClick={() => {
                    setSelectedPickupLocation(location.value)
                    setCustomLocation("")
                  }}
                  className={`flex items-center gap-3 rounded-xl border p-4 text-left transition-all ${
                    selectedPickupLocation === location.value
                      ? "border-primary bg-primary/10 shadow-sm"
                      : "border-border/50 hover:border-primary/50 hover:bg-secondary"
                  }`}
                >
                  <div className={`flex h-10 w-10 items-center justify-center rounded-lg ${
                    selectedPickupLocation === location.value ? "bg-primary/20" : "bg-secondary"
                  }`}>
                    <MapPin className={`h-5 w-5 ${
                      selectedPickupLocation === location.value ? "text-primary" : "text-muted-foreground"
                    }`} />
                  </div>
                  <span className={`font-medium ${
                    selectedPickupLocation === location.value ? "text-primary" : "text-foreground"
                  }`}>
                    {location.label}
                  </span>
                </button>
              ))}
              
              {/* Custom Location Option */}
              <button
                onClick={() => setSelectedPickupLocation("custom")}
                className={`flex items-center gap-3 rounded-xl border p-4 text-left transition-all ${
                  selectedPickupLocation === "custom"
                    ? "border-primary bg-primary/10 shadow-sm"
                    : "border-border/50 hover:border-primary/50 hover:bg-secondary"
                }`}
              >
                <div className={`flex h-10 w-10 items-center justify-center rounded-lg ${
                  selectedPickupLocation === "custom" ? "bg-primary/20" : "bg-secondary"
                }`}>
                  <Navigation className={`h-5 w-5 ${
                    selectedPickupLocation === "custom" ? "text-primary" : "text-muted-foreground"
                  }`} />
                </div>
                <span className={`font-medium ${
                  selectedPickupLocation === "custom" ? "text-primary" : "text-foreground"
                }`}>
                  Choose Custom Location
                </span>
              </button>
            </div>

            {/* Custom Location Input */}
            {selectedPickupLocation === "custom" && (
              <div className="space-y-2 animate-in fade-in slide-in-from-top-2 duration-200">
                <Label htmlFor="customLocationInput" className="text-sm font-medium">
                  Enter Custom Location
                </Label>
                <Input
                  id="customLocationInput"
                  placeholder="e.g., Library Entrance, Parking Lot A"
                  value={customLocation}
                  onChange={(e) => setCustomLocation(e.target.value)}
                  className="h-12 rounded-xl"
                />
              </div>
            )}
          </div>

          <DialogFooter className="gap-2 sm:gap-0">
            <Button
              variant="outline"
              onClick={() => setPickupModalItem(null)}
              className="rounded-xl"
            >
              Cancel
            </Button>
            <Button
              onClick={handleConfirmPickup}
              disabled={!isPickupValid}
              className="rounded-xl gap-2"
            >
              <CheckCircle2 className="h-4 w-4" />
              Confirm Pickup
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Complete Confirmation Dialog */}
      <AlertDialog open={!!itemToComplete} onOpenChange={() => setItemToComplete(null)}>
        <AlertDialogContent className="rounded-2xl">
          <AlertDialogHeader>
            <AlertDialogTitle>Mark Pickup as Completed?</AlertDialogTitle>
            <AlertDialogDescription>
              This will mark the food pickup as completed. Thank you for helping reduce food waste!
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="rounded-xl">Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleConfirmComplete} className="rounded-xl bg-green-600 hover:bg-green-700">
              Yes, mark as completed
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Remove Confirmation Dialog */}
      <AlertDialog open={!!itemToRemove} onOpenChange={() => setItemToRemove(null)}>
        <AlertDialogContent className="rounded-2xl">
          <AlertDialogHeader>
            <AlertDialogTitle>Remove from List?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently remove this food item from the list.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="rounded-xl">Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleConfirmRemove} className="rounded-xl bg-destructive hover:bg-destructive/90">
              Yes, remove
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </section>
  )
}
